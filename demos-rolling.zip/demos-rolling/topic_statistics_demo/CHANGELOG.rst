^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package topic_statistics_demo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.31.1 (2023-09-07)
-------------------

0.31.0 (2023-08-21)
-------------------

0.30.1 (2023-07-11)
-------------------

0.30.0 (2023-06-12)
-------------------

0.29.0 (2023-06-07)
-------------------

0.28.1 (2023-05-11)
-------------------

0.28.0 (2023-04-27)
-------------------

0.27.0 (2023-04-13)
-------------------

0.26.0 (2023-04-11)
-------------------

0.25.0 (2023-03-01)
-------------------

0.24.1 (2023-02-24)
-------------------

0.24.0 (2023-02-14)
-------------------
* Update the demos to C++17. (`#594 <https://github.com/ros2/demos/issues/594>`_)
* [rolling] Update maintainers - 2022-11-07 (`#589 <https://github.com/ros2/demos/issues/589>`_)
* Contributors: Audrow Nash, Chris Lalancette

0.23.0 (2022-11-02)
-------------------

0.22.0 (2022-09-13)
-------------------

0.21.0 (2022-04-29)
-------------------

0.20.1 (2022-04-08)
-------------------

0.20.0 (2022-03-01)
-------------------
* Install includes to include/${PROJECT_NAME} (`#548 <https://github.com/ros2/demos/issues/548>`_)
* Contributors: Shane Loretz

0.19.0 (2022-01-14)
-------------------

0.18.0 (2021-12-17)
-------------------
* Additional fixes for documentation in demos. (`#538 <https://github.com/ros2/demos/issues/538>`_)
* Contributors: Chris Lalancette

0.17.0 (2021-10-18)
-------------------
* Fixing deprecated subscriber callback warnings (`#532 <https://github.com/ros2/demos/issues/532>`_)
* Contributors: Abrar Rahman Protyasha

0.16.0 (2021-08-11)
-------------------

0.15.0 (2021-05-14)
-------------------

0.14.2 (2021-04-26)
-------------------

0.14.1 (2021-04-19)
-------------------

0.14.0 (2021-04-06)
-------------------
* Change index.ros.org -> docs.ros.org. (`#496 <https://github.com/ros2/demos/issues/496>`_)
* Contributors: Chris Lalancette

0.13.0 (2021-03-25)
-------------------

0.12.1 (2021-03-18)
-------------------

0.12.0 (2021-01-25)
-------------------
* Update logging macros (`#476 <https://github.com/ros2/demos/issues/476>`_)
* Contributors: Audrow Nash

0.11.0 (2020-12-10)
-------------------
* Update the package.xml files with the latest Open Robotics maintainers (`#466 <https://github.com/ros2/demos/issues/466>`_)
* Contributors: Michael Jeronimo

0.10.1 (2020-09-21)
-------------------
* Create new topic statistics demo package (`#454 <https://github.com/ros2/demos/issues/454>`_)
* Contributors: Prajakta Gokhale
